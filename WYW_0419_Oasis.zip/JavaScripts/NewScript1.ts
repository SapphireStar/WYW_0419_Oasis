﻿/*
 * @Author: Tianyi
 * @Date: 2022-08-18 20:54:11
 * @LastEditors: Tianyi
 * @LastEditTime: 2022-08-19 10:14:48
 * @FilePath: \WYW_0419_Oasis\JavaScripts\NewScript1.ts
 * @Description: 
 * 
 * Copyright (c) 2022 by error: git config user.name && git config user.email & please set dead value or install git, All Rights Reserved. 
 */

@MWCore.MWClass
export default class NewScript1 extends MWCore.MWScript {

	/** 当脚本被实例后，会在第一帧更新前调用此函数 */
	protected onStart(): void {

	}

	/** 
	 * 每帧被执行,与上一帧的延迟 dt 秒
	 * 此函数执行需要将this.bUseUpdate赋值为true
	 */
	protected onUpdate(dt: number): void {

	}

	/** 脚本被销毁时最后一帧执行完调用此函数 */
	protected onDestroy(): void {

	}

}
