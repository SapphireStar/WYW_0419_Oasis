﻿import { ModuleC } from "odin";
import { NpcModuleS } from "./NpcModuleS";

export class NpcModuleC extends ModuleC<NpcModuleS, null> {

    onStart(): void {

    }
}
