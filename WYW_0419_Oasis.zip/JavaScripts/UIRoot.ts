﻿import { UI } from "odin";

@MWGameUI.MWUIMono
export default class UIRoot extends UI {

}
