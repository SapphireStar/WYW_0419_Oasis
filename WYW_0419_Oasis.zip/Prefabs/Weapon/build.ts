import * as foreign0 from './Script/Rifle';


export const MWModuleMap = {
    'Script/Rifle': foreign0, 
};
